﻿using System.Windows;

namespace CalculatorClientGUI
{
    public partial class App : Application
    {
    }
}
